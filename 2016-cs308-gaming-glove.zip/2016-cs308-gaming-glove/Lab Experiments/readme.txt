Group A
Pratik Fegade : 120050004
Devdeep Ray   : 120050007
Haren Saga    : 120050072